Frontend (Vite + React)

Install:
  cd frontend
  npm install
  npm run dev

Notes:
- Frontend expects backend at http://localhost:3001/productos
- If backend not running, frontend will show empty list
